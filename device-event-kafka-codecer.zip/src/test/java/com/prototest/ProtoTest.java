package com.prototest;

import static com.sitewhere.grpc.model.CommonModel.*;
import static com.sitewhere.grpc.model.DeviceEventModel.* ;

import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ProtoTest {
    @Test
    public void deCoderTest() throws IOException {
        // prepare the data being tested
        GEnrichedEventPayload data = createMockGEnrichedEventPayload() ;
        byte[] encoded = new GEnrichedEventPayloadSerializer().serialize("na", data) ;

        // test the deserializer
        GEnrichedEventPayload decoded = new GEnrichedEventPayloadDeserializer().deserialize("na", encoded) ;

        // assert if we did it well
        Assert.assertEquals(decoded.getContext().getDeviceId(), deviceId);
    }

    // ------ Mock data for tests
    private static GEnrichedEventPayload createMockGEnrichedEventPayload() throws IOException {
        GEnrichedEventPayload.Builder grpc = GEnrichedEventPayload.newBuilder();
        grpc.setContext(createMockGDeviceEventContext()) ;
        grpc.setEvent(createGAnyDeviceEvent()) ;
        return grpc.build() ;
    }

    private static GAnyDeviceEvent createGAnyDeviceEvent() {
        GAnyDeviceEvent.Builder grpc = GAnyDeviceEvent.newBuilder();
        grpc.setMeasurement(createDeviceMeasurement()) ;
        return grpc.build() ;
    }

    public static GDeviceMeasurement createDeviceMeasurement() {
        GDeviceMeasurement.Builder grpc = GDeviceMeasurement.newBuilder();
        grpc.setName("f1");
        grpc.setValue(133.14);
        grpc.setEvent(createMockGDeviceEvent());
        return grpc.build();
    }

    private static GDeviceEventContext createMockGDeviceEventContext() {
        GDeviceEventContext.Builder grpc = GDeviceEventContext.newBuilder();
        grpc.setDeviceId(deviceId);
        grpc.setDeviceTypeId(deviceTypeId);
        // grpc.setParentDeviceId(..)
        grpc.setDeviceStatus(GOptionalString.newBuilder().setValue("On"));

        Map<String, String> allDeviceMetaData = new HashMap<String, String>() ;
        allDeviceMetaData.put("name1", "val1") ;
        allDeviceMetaData.put("name2", "val2") ;
        grpc.putAllDeviceMetadata(allDeviceMetaData);
        grpc.setAssignmentStatus(GDeviceAssignmentStatus.ASSN_STATUS_ACTIVE) ;

        Map<String, String> allAssignmentMetaData = new HashMap<String, String>() ;
        allAssignmentMetaData.put("ass1", "valass1") ;
        grpc.putAllAssignmentMetadata(allAssignmentMetaData);
        return grpc.build();
    }

    private static GDeviceEvent createMockGDeviceEvent() {
        GDeviceEvent.Builder grpc = GDeviceEvent.newBuilder();
        grpc.setId(eventId);
        grpc.setEventType(GDeviceEventType.EVENT_TYPE_MEASUREMENT);
        grpc.setDeviceId(deviceId);
        grpc.setDeviceAssignmentId(assignmentId);
        grpc.setCustomerId(customerId);
        grpc.setAreaId(areaId);
        grpc.setAssetId(assetId);
        grpc.setEventDate(System.currentTimeMillis());
        grpc.setReceivedDate(System.currentTimeMillis());
        Map<String, String> allEventMetaData = new HashMap<String, String>() ;
        allEventMetaData.put("ename1", "val1") ;
        allEventMetaData.put("ename2", "val2") ;
        grpc.putAllMetadata(allEventMetaData);
        return grpc.build();
    }

    private static GUUID generateMockGuuid(long lsb, long msb) {
        GUUID.Builder grpc = GUUID.newBuilder();
        grpc.setMsb(msb);
        grpc.setLsb(lsb);
        return grpc.build();

    }

    private static GUUID deviceId = generateMockGuuid(1, 2) ;
    private static GUUID deviceTypeId = generateMockGuuid(3, 4) ;
    private static GUUID eventId = generateMockGuuid(5, 6) ;
    private static GUUID assignmentId =  generateMockGuuid(7, 8) ;
    private static GUUID customerId =  generateMockGuuid(9, 10) ;
    private static GUUID areaId =  generateMockGuuid(11, 12) ;
    private static GUUID assetId =  generateMockGuuid(13, 14) ;
}

